const PlaceholderPage = () => (
  <div className="flex items-center justify-center h-64">
    <div className="text-center">
      <p className="text-4xl mb-3">🚧</p>
      <p className="text-white font-semibold">Module en développement</p>
      <p className="text-slate-400 text-sm mt-1">Disponible dans une prochaine sprint</p>
    </div>
  </div>
);

export default PlaceholderPage;
