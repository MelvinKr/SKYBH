import { useAuth } from '../hooks/use-auth';
import { ROLE_LABELS } from '../constants/roles';

const Dashboard = () => {
  const { profile, role } = useAuth();

  const greeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Bonjour';
    if (hour < 18) return 'Bon après-midi';
    return 'Bonsoir';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold text-white">
          {greeting()}, {profile?.displayName?.split(' ')[0] || 'Pilote'} 👋
        </h2>
        <p className="text-slate-400 text-sm mt-1">
          {ROLE_LABELS[role]} · {new Date().toLocaleDateString('fr-FR', {
            weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
          })}
        </p>
      </div>

      {/* Cards placeholder modules */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <ModuleCard
          title="Flotte"
          subtitle="Avions & potentiels"
          status="À venir — S2"
          icon="✈️"
          color="sky"
        />
        <ModuleCard
          title="Planning"
          subtitle="Rotations & affectations"
          status="À venir — S3"
          icon="🗓️"
          color="violet"
        />
        <ModuleCard
          title="Opérations Sol"
          subtitle="Check-in & manifeste"
          status="À venir — S4"
          icon="🧳"
          color="emerald"
        />
        <ModuleCard
          title="Commercial"
          subtitle="Réservations & tarifs"
          status="À venir — S5"
          icon="📊"
          color="amber"
        />
        <ModuleCard
          title="Direction"
          subtitle="KPIs & exports"
          status="À venir — S6"
          icon="🏢"
          color="rose"
        />
      </div>

      {/* METAR placeholder */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
        <div className="flex items-center gap-2 mb-3">
          <span className="text-base">🌤️</span>
          <h3 className="text-white font-medium text-sm">Météo — TFFJ / TFFG / TQPF</h3>
          <span className="ml-auto text-xs text-slate-500">METAR disponible dès S3</span>
        </div>
        <div className="flex gap-3">
          {['TFFJ', 'TFFG', 'TQPF'].map(icao => (
            <div key={icao} className="flex-1 bg-slate-800 rounded-xl p-3 text-center">
              <p className="text-slate-300 font-mono text-sm font-bold">{icao}</p>
              <p className="text-slate-500 text-xs mt-1">—</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

/**
 * @param {Object} props
 * @param {string} props.title
 * @param {string} props.subtitle
 * @param {string} props.status
 * @param {string} props.icon
 * @param {string} props.color
 */
const ModuleCard = ({ title, subtitle, status, icon, color }) => {
  const colors = {
    sky:     'border-sky-500/20 bg-sky-500/5',
    violet:  'border-violet-500/20 bg-violet-500/5',
    emerald: 'border-emerald-500/20 bg-emerald-500/5',
    amber:   'border-amber-500/20 bg-amber-500/5',
    rose:    'border-rose-500/20 bg-rose-500/5',
  };

  return (
    <div className={`border rounded-2xl p-4 ${colors[color] || colors.sky}`}>
      <div className="flex items-start justify-between">
        <span className="text-2xl">{icon}</span>
        <span className="text-xs text-slate-500 bg-slate-800 rounded-lg px-2 py-0.5">{status}</span>
      </div>
      <h3 className="text-white font-semibold text-sm mt-3">{title}</h3>
      <p className="text-slate-400 text-xs mt-0.5">{subtitle}</p>
    </div>
  );
};

export default Dashboard;
