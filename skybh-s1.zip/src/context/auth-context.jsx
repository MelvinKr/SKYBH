import { createContext, useContext, useEffect, useState } from 'react';
import {
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
} from 'firebase/auth';
import { auth } from '../firebase';
import { getUserProfile, createUserProfile } from '../services/user-service';

/**
 * @typedef {Object} AuthContextValue
 * @property {import('firebase/auth').User|null} user       - Utilisateur Firebase Auth
 * @property {import('../services/user-service').UserProfile|null} profile - Profil Firestore
 * @property {string|null} role                             - Rôle courant
 * @property {boolean} loading                              - Chargement initial
 * @property {string|null} error                            - Message d'erreur
 * @property {(email: string, password: string) => Promise<void>} login
 * @property {() => Promise<void>} logout
 */

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser]       = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      try {
        if (firebaseUser) {
          setUser(firebaseUser);
          await createUserProfile(firebaseUser.uid, firebaseUser.email, firebaseUser.displayName || firebaseUser.email);
          const prof = await getUserProfile(firebaseUser.uid);
          if (prof && !prof.active) {
            await signOut(auth);
            setError('Compte désactivé. Contactez un administrateur.');
            setUser(null);
            setProfile(null);
          } else {
            setProfile(prof);
            setError(null);
          }
        } else {
          setUser(null);
          setProfile(null);
        }
      } catch (err) {
        console.error('[AuthContext]', err);
        setError('Erreur de connexion au serveur.');
      } finally {
        setLoading(false);
      }
    });
    return unsubscribe;
  }, []);

  const login = async (email, password) => {
    setError(null);
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (err) {
      console.error('[AuthContext] login:', err);
      const messages = {
        'auth/user-not-found':  'Aucun compte avec cet email.',
        'auth/wrong-password':  'Mot de passe incorrect.',
        'auth/too-many-requests': 'Trop de tentatives. Réessayez dans quelques minutes.',
        'auth/network-request-failed': 'Pas de connexion réseau.',
      };
      throw new Error(messages[err.code] || 'Erreur de connexion. Vérifiez vos identifiants.');
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
    } catch (err) {
      console.error('[AuthContext] logout:', err);
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      profile,
      role: profile?.role ?? null,
      loading,
      error,
      login,
      logout,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

/** @returns {AuthContextValue} */
export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth doit être utilisé dans <AuthProvider>');
  return ctx;
};
