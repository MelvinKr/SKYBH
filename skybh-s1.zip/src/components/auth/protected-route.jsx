import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../hooks/use-auth';
import { MODULE_ACCESS } from '../../constants/roles';
import { ROUTES } from '../../constants/routes';

/**
 * @param {Object} props
 * @param {React.ReactNode} props.children
 * @param {string} [props.module] - Clé du module pour vérifier les accès
 */
const ProtectedRoute = ({ children, module }) => {
  const { user, role, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-2 border-sky-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-slate-400 text-sm">Chargement…</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to={ROUTES.LOGIN} state={{ from: location }} replace />;
  }

  if (module && role && MODULE_ACCESS[module] && !MODULE_ACCESS[module].includes(role)) {
    return <Navigate to={ROUTES.DASHBOARD} replace />;
  }

  return children;
};

export default ProtectedRoute;
