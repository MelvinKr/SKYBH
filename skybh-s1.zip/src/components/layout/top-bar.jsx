/**
 * @param {Object} props
 * @param {() => void} props.onMenuClick
 * @param {string} props.title
 */
const TopBar = ({ onMenuClick, title }) => (
  <header className="sticky top-0 z-10 flex items-center gap-4 px-4 py-3
                     bg-slate-950/80 backdrop-blur border-b border-slate-800 lg:px-6">
    {/* Burger menu (mobile seulement) */}
    <button
      onClick={onMenuClick}
      className="lg:hidden flex items-center justify-center w-9 h-9
                 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
      aria-label="Ouvrir le menu"
    >
      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
          d="M4 6h16M4 12h16M4 18h16" />
      </svg>
    </button>

    <h1 className="text-white font-semibold text-base flex-1">{title}</h1>

    {/* Indicateur connexion réseau */}
    <NetworkStatus />
  </header>
);

const NetworkStatus = () => {
  const [online, setOnline] = useState(navigator.onLine);

  useEffect(() => {
    const on  = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => {
      window.removeEventListener('online', on);
      window.removeEventListener('offline', off);
    };
  }, []);

  if (online) return null;

  return (
    <div className="flex items-center gap-1.5 bg-amber-500/10 border border-amber-500/30
                    rounded-lg px-2.5 py-1">
      <div className="w-1.5 h-1.5 rounded-full bg-amber-400" />
      <span className="text-amber-400 text-xs font-medium">Hors ligne</span>
    </div>
  );
};

// Imports nécessaires pour NetworkStatus
import { useState, useEffect } from 'react';

export default TopBar;
