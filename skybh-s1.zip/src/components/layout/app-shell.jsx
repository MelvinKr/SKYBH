import { useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import Sidebar from './sidebar';
import TopBar from './top-bar';
import { ROUTES } from '../../constants/routes';

const PAGE_TITLES = {
  [ROUTES.DASHBOARD]:  'Tableau de bord',
  [ROUTES.FLOTTE]:     'Gestion de la Flotte',
  [ROUTES.PLANNING]:   'Planning des Vols',
  [ROUTES.OPERATIONS]: 'Opérations Sol',
  [ROUTES.COMMERCIAL]: 'Commercial',
  [ROUTES.DIRECTION]:  'Direction',
};

const AppShell = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();
  const title = PAGE_TITLES[location.pathname] || 'SKYBH';

  return (
    <div className="flex h-screen bg-slate-950 overflow-hidden">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <TopBar
          onMenuClick={() => setSidebarOpen(true)}
          title={title}
        />
        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AppShell;
