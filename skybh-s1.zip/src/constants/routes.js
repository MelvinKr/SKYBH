export const ROUTES = {
  LOGIN:      '/login',
  DASHBOARD:  '/',
  FLOTTE:     '/flotte',
  PLANNING:   '/planning',
  OPERATIONS: '/operations',
  COMMERCIAL: '/commercial',
  DIRECTION:  '/direction',
};
