/** @type {Object.<string, string>} */
export const ROLES = {
  ADMIN: 'admin',
  OPS: 'ops',
  PILOTE: 'pilote',
  AGENT_SOL: 'agent_sol',
};

/** Labels français pour l'interface */
export const ROLE_LABELS = {
  admin: 'Administrateur',
  ops: 'Opérations',
  pilote: 'Pilote',
  agent_sol: 'Agent Sol',
};

/**
 * Définit quels rôles peuvent accéder à chaque module.
 * @type {Object.<string, string[]>}
 */
export const MODULE_ACCESS = {
  flotte:      [ROLES.ADMIN, ROLES.OPS],
  planning:    [ROLES.ADMIN, ROLES.OPS, ROLES.PILOTE],
  operations:  [ROLES.ADMIN, ROLES.OPS, ROLES.AGENT_SOL],
  commercial:  [ROLES.ADMIN, ROLES.OPS],
  direction:   [ROLES.ADMIN],
};
