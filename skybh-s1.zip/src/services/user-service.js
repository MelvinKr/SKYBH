import { doc, getDoc, setDoc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';

/**
 * @typedef {Object} UserProfile
 * @property {string} uid
 * @property {string} email
 * @property {string} displayName
 * @property {'admin'|'ops'|'pilote'|'agent_sol'} role
 * @property {string} [licenseNumber]
 * @property {boolean} active
 * @property {import('firebase/firestore').Timestamp} createdAt
 * @property {import('firebase/firestore').Timestamp} lastLogin
 */

/**
 * Récupère le profil utilisateur depuis Firestore.
 * @param {string} uid
 * @returns {Promise<UserProfile|null>}
 */
export const getUserProfile = async (uid) => {
  try {
    const ref = doc(db, 'users', uid);
    const snap = await getDoc(ref);
    if (!snap.exists()) return null;
    return { uid: snap.id, ...snap.data() };
  } catch (err) {
    console.error('[UserService] getUserProfile:', err);
    throw new Error('Impossible de récupérer le profil utilisateur.');
  }
};

/**
 * Crée ou met à jour le profil au premier login.
 * @param {string} uid
 * @param {string} email
 * @param {string} displayName
 */
export const createUserProfile = async (uid, email, displayName) => {
  try {
    const ref = doc(db, 'users', uid);
    const snap = await getDoc(ref);
    if (!snap.exists()) {
      await setDoc(ref, {
        email,
        displayName,
        role: 'agent_sol', // Rôle par défaut le plus restrictif
        active: true,
        createdAt: serverTimestamp(),
        lastLogin: serverTimestamp(),
      });
    } else {
      await updateDoc(ref, { lastLogin: serverTimestamp() });
    }
  } catch (err) {
    console.error('[UserService] createUserProfile:', err);
    throw new Error('Erreur lors de la création du profil.');
  }
};

/**
 * Met à jour le rôle d'un utilisateur (admin seulement, vérifié par Firestore Rules).
 * @param {string} uid
 * @param {'admin'|'ops'|'pilote'|'agent_sol'} role
 */
export const updateUserRole = async (uid, role) => {
  try {
    const ref = doc(db, 'users', uid);
    await updateDoc(ref, { role });
  } catch (err) {
    console.error('[UserService] updateUserRole:', err);
    throw new Error('Impossible de modifier le rôle. Permissions insuffisantes.');
  }
};
