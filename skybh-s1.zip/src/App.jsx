import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from './context/auth-context'
import { ROUTES } from './constants/routes'

import AppShell from './components/layout/app-shell'
import ProtectedRoute from './components/auth/protected-route'

import LoginPage from './pages/login'
import DashboardPage from './pages/dashboard'
import FlottePage from './pages/flotte/index'
import PlanningPage from './pages/planning/index'
import OperationsPage from './pages/operations/index'
import CommercialPage from './pages/commercial/index'
import DirectionPage from './pages/direction/index'

const App = () => {
  const { firebaseUser, loading } = useAuth()

  if (loading) {
    return (
      <div className="min-h-screen bg-sky-950 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-10 h-10 border-2 border-cloud-200/20 border-t-signal-amber rounded-full animate-spin" />
          <span className="font-body text-cloud-300 text-sm tracking-widest uppercase">
            Initialisation…
          </span>
        </div>
      </div>
    )
  }

  return (
    <Routes>
      {/* Public */}
      <Route
        path={ROUTES.LOGIN}
        element={
          firebaseUser
            ? <Navigate to={ROUTES.DASHBOARD} replace />
            : <LoginPage />
        }
      />

      {/* Protected — with AppShell */}
      <Route
        path="/*"
        element={
          <ProtectedRoute>
            <AppShell>
              <Routes>
                <Route path="/" element={<DashboardPage />} />
                <Route path="/flotte" element={<FlottePage />} />
                <Route path="/planning" element={<PlanningPage />} />
                <Route path="/operations" element={<OperationsPage />} />
                <Route path="/commercial" element={<CommercialPage />} />
                <Route path="/direction" element={<DirectionPage />} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </AppShell>
          </ProtectedRoute>
        }
      />
    </Routes>
  )
}

export default App
