// Re-export depuis auth-context pour respecter la convention hooks/
export { useAuth } from '../context/auth-context';
