# SKYBH — SBH Commuter Operations Platform

## Setup

### 1. Créer le projet Firebase
1. Aller sur [console.firebase.google.com](https://console.firebase.google.com)
2. Créer un nouveau projet `skybh-prod`
3. Activer **Authentication** → Email/Password
4. Activer **Firestore Database** en mode production
5. Copier les clés de configuration

### 2. Variables d'environnement
```bash
cp .env.example .env.local
# Remplir avec vos clés Firebase
```

### 3. Déployer les règles Firestore
```bash
npm install -g firebase-tools
firebase login
firebase init firestore
firebase deploy --only firestore:rules
```

### 4. Créer le premier compte admin
Dans la console Firebase → Authentication → Add user, puis dans Firestore → users/{uid} → set `role: "admin"`.

### 5. Installer et lancer
```bash
npm install
npm run dev
```

## Structure
```
src/
├── components/     → Composants réutilisables
├── pages/          → Une page par module
├── hooks/          → Custom hooks Firebase
├── services/       → Interactions Firestore
├── utils/          → Calculs métier (W&B, potentiels)
├── context/        → AuthContext
└── constants/      → Routes, rôles, config
```

## Rôles
| Rôle       | Accès |
|------------|-------|
| admin      | Tout  |
| ops        | Flotte + Planning + Opérations + Commercial |
| pilote     | Planning (lecture) |
| agent_sol  | Opérations Sol |
